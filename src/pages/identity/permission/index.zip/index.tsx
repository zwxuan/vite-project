import React, { useState } from 'react';
import { Tree, Table, Button, message, Checkbox, Row, Col } from 'antd';
import type { Key } from 'antd/es/table/interface';
import type { DataNode } from 'antd/es/tree';
import type { ColumnsType } from 'antd/es/table';
import type { CheckboxChangeEvent } from 'antd/es/checkbox';
import '@/pages/page_list.less';
// import './permission.less';

interface TreeNode extends DataNode {
  title: string;
  key: string;
  children?: TreeNode[];
  checked?: boolean;
}

interface Activity {
  key: string;
  name: string;
  checked: boolean;
}

interface DataType {
  key: string;
  service: string;
  activities: Activity[];
  checked: boolean;
}

// Mock API data for different menu items
const mockDataMap: Record<string, DataType[]> = {
  '0-0': [
    {
      key: '1',
      service: '人力业务单元',
      checked: false,
      activities: [
        { key: '1-1', name: '查看', checked: false },
        { key: '1-2', name: '编辑', checked: false },
        { key: '1-3', name: '删除', checked: false },
        { key: '2-1', name: '查看2', checked: false },
        { key: '2-2', name: '编辑2', checked: false },
        { key: '2-3', name: '删除2', checked: false },
        { key: '3-1', name: '查看3', checked: false },
        { key: '3-2', name: '编辑3', checked: false },
        { key: '3-3', name: '删除3', checked: false },
        { key: '4-1', name: '查看4', checked: false },
        { key: '4-2', name: '编辑4', checked: false },
        { key: '4-3', name: '删除4', checked: false },
        { key: '5-1', name: '查看5', checked: false },
        { key: '5-2', name: '编辑5', checked: false },
        { key: '5-3', name: '删除5', checked: false },
      ],
    },
    {
      key: '2',
      service: '财务业务单元',
      checked: false,
      activities: [
        { key: '2-1', name: '查看', checked: false },
        { key: '2-2', name: '导出', checked: false },
      ],
    },
  ],
  '0-1': [
    {
      key: '3',
      service: '基础数据服务',
      checked: false,
      activities: [
        { key: '3-1', name: '查看', checked: false },
        { key: '3-2', name: '编辑', checked: false },
      ],
    },
  ],
};

// Keep track of checked states for each menu item
interface MenuState {
  [key: string]: {
    data: DataType[];
  };
}

const PermissionManagement: React.FC = () => {
  const [tableData, setTableData] = useState<DataType[]>([]);
  const [selectedMenuKey, setSelectedMenuKey] = useState<string>('');
  const [checkedKeys, setCheckedKeys] = useState<Key[]>([]);
  const [halfCheckedKeys, setHalfCheckedKeys] = useState<Key[]>([]);
  // Add menuState to keep track of each menu's data state
  const [menuState, setMenuState] = useState<MenuState>(() => {
    // Initialize with mockDataMap
    const initialState: MenuState = {};
    Object.entries(mockDataMap).forEach(([key, data]) => {
      initialState[key] = {
        data: [...data],
      };
    });
    return initialState;
  });
  
  const treeData: TreeNode[]= [
    {
      title: '组织管理',
      key: 'sub1',
      selectable: false,
      children: [
        {
          title: '组织管理',
          key: '0-0',
          checked: false,
        },
        {
          title: '基础数据',
          key: '0-1',
          checked: false,
        },
      ],
    },
  ];
  // Handle menu selection
  const onSelect = (selectedKeys: Key[]) => {
    const key = selectedKeys[0] as string;
    setSelectedMenuKey(key);
    if (key && menuState[key]) {
      setTableData(menuState[key].data);
      
      // Sync tree state with table state when switching
      const data = menuState[key].data;
      const allChecked = data.every(item => 
        item.checked && item.activities.every(activity => activity.checked)
      );
      const noneChecked = data.every(item => 
        !item.checked && item.activities.every(activity => !activity.checked)
      );
      
      if (allChecked) {
        setCheckedKeys(prev => [...prev.filter(k => k !== key), key]);
        setHalfCheckedKeys(prev => prev.filter(k => k !== key));
      } else if (noneChecked) {
        setCheckedKeys(prev => prev.filter(k => k !== key));
        setHalfCheckedKeys(prev => prev.filter(k => k !== key));
      } else {
        setCheckedKeys(prev => prev.filter(k => k !== key));
        setHalfCheckedKeys(prev => [...prev.filter(k => k !== key), key]);
      }
    }
  };

  // Handle Tree checkbox changes
  const onCheck = (checked: Key[] | { checked: Key[]; halfChecked: Key[] }, info: any) => {
    const checkedKeysArray = Array.isArray(checked) ? checked : checked.checked;
    const halfCheckedKeysArray = Array.isArray(checked) ? [] : checked.halfChecked;
    
    // Get the clicked node key from info
    const clickedKey = info.node.key as string;
    let newCheckedKeys = [...checkedKeysArray];
    let newHalfCheckedKeys = [...halfCheckedKeysArray];

    // Handle parent-child relationship
    if (clickedKey === 'sub1') {
      // If parent is clicked
      const isChecking = newCheckedKeys.includes('sub1');
      const childKeys = Object.keys(menuState).filter(key => key.startsWith('0-'));
      
      if (isChecking) {
        // Add all children to checked
        newCheckedKeys = [...new Set([...newCheckedKeys, ...childKeys])];
        newHalfCheckedKeys = newHalfCheckedKeys.filter(key => key !== 'sub1');
        
        // Update all child nodes data to checked state
        const newMenuState = { ...menuState };
        childKeys.forEach(key => {
          if (newMenuState[key]) {
            newMenuState[key].data = newMenuState[key].data.map(item => ({
              ...item,
              checked: true,
              activities: item.activities.map(activity => ({
                ...activity,
                checked: true
              }))
            }));
          }
        });
        setMenuState(newMenuState);
        
        // Update table data if currently viewing a child
        if (selectedMenuKey && childKeys.includes(selectedMenuKey)) {
          setTableData(newMenuState[selectedMenuKey].data);
        }
      } else {
        // Remove all children from checked and half-checked
        newCheckedKeys = newCheckedKeys.filter(key => !childKeys.includes(key.toString()) && key !== 'sub1');
        newHalfCheckedKeys = newHalfCheckedKeys.filter(key => !childKeys.includes(key.toString()) && key !== 'sub1');
        
        // Clear all child nodes data
        const newMenuState = { ...menuState };
        childKeys.forEach(key => {
          if (newMenuState[key]) {
            newMenuState[key].data = newMenuState[key].data.map(item => ({
              ...item,
              checked: false,
              activities: item.activities.map(activity => ({
                ...activity,
                checked: false
              }))
            }));
          }
        });
        setMenuState(newMenuState);
        
        // Update table data if currently viewing a child
        if (selectedMenuKey && childKeys.includes(selectedMenuKey)) {
          setTableData(newMenuState[selectedMenuKey].data);
        }
      }
    } else if (clickedKey.startsWith('0-')) {
      // If child is clicked
      const siblingKeys = Object.keys(menuState).filter(key => 
        key !== clickedKey && key.startsWith('0-')
      );
      const isChecking = newCheckedKeys.includes(clickedKey);
      
      // Update the clicked node's data
      const newMenuState = { ...menuState };
      if (newMenuState[clickedKey]) {
        newMenuState[clickedKey].data = newMenuState[clickedKey].data.map(item => ({
          ...item,
          checked: isChecking,
          activities: item.activities.map(activity => ({
            ...activity,
            checked: isChecking
          }))
        }));
        setMenuState(newMenuState);
        
        // Update table data if currently viewing this node
        if (selectedMenuKey === clickedKey) {
          setTableData(newMenuState[clickedKey].data);
        }
      }
      
      if (isChecking) {
        // Check if other siblings are also checked
        if (siblingKeys.every(key => newCheckedKeys.includes(key))) {
          // If all siblings are checked, check parent
          newCheckedKeys = [...newCheckedKeys, 'sub1'];
          newHalfCheckedKeys = newHalfCheckedKeys.filter(key => key !== 'sub1');
        } else {
          // If not all siblings are checked, make parent half-checked
          newCheckedKeys = newCheckedKeys.filter(key => key !== 'sub1');
          newHalfCheckedKeys = [...new Set([...newHalfCheckedKeys, 'sub1'])];
        }
      } else {
        // If unchecking a child
        newCheckedKeys = newCheckedKeys.filter(key => key !== 'sub1');
        
        // Check if any siblings are checked or half-checked
        const anySiblingCheckedOrHalfChecked = siblingKeys.some(key => 
          newCheckedKeys.includes(key) || newHalfCheckedKeys.includes(key)
        );
        
        if (anySiblingCheckedOrHalfChecked) {
          // If any sibling is checked or half-checked, keep parent half-checked
          newHalfCheckedKeys = [...new Set([...newHalfCheckedKeys, 'sub1'])];
        } else {
          // If no siblings are checked or half-checked, remove parent from half-checked
          newHalfCheckedKeys = newHalfCheckedKeys.filter(key => key !== 'sub1');
        }
      }
    }

    setCheckedKeys(newCheckedKeys);
    setHalfCheckedKeys(newHalfCheckedKeys);
  };

  const updateTreeState = (newData: DataType[], currentKey: string) => {
    // Check if current node has any checked items
    const allChecked = newData.every(item => 
      item.checked && item.activities.every(activity => activity.checked)
    );
    const noneChecked = newData.every(item => 
      !item.checked && item.activities.every(activity => !activity.checked)
    );
    const partiallyChecked = !allChecked && !noneChecked || newData.some(item => 
      item.activities.some(activity => activity.checked)
    );
    
    // Get other child nodes' states
    const siblingKeys = Object.keys(menuState).filter(key => 
      key !== currentKey && key.startsWith('0-')
    );
    
    const siblingsState = siblingKeys.map(key => {
      const siblingData = menuState[key]?.data;
      return {
        key,
        allChecked: siblingData?.every(item => 
          item.checked && item.activities.every(activity => activity.checked)
        ),
        noneChecked: siblingData?.every(item => 
          !item.checked && item.activities.every(activity => !activity.checked)
        )
      };
    });

    if (allChecked) {
      if (siblingsState.every(s => s.allChecked)) {
        // All siblings fully checked, parent should be checked
        setCheckedKeys(prev => [...prev.filter(key => key !== 'sub1' && !key.toString().startsWith('0-')), ...siblingKeys, currentKey, 'sub1']);
        setHalfCheckedKeys(prev => prev.filter(key => key !== 'sub1'));
      } else {
        // Current child fully checked, but not all siblings, parent should be half-checked
        setCheckedKeys(prev => [...prev.filter(key => key !== 'sub1' && !key.toString().startsWith('0-')), currentKey]);
        setHalfCheckedKeys(prev => [...prev.filter(key => key !== 'sub1'), 'sub1']);
      }
    } else if (noneChecked) {
      if (siblingsState.every(s => s.noneChecked)) {
        // All siblings have nothing checked, remove all checks and half-checks
        setCheckedKeys(prev => prev.filter(key => key !== 'sub1' && !key.toString().startsWith('0-')));
        setHalfCheckedKeys(prev => prev.filter(key => !['sub1', currentKey].includes(key.toString())));
      } else {
        // Current child has nothing checked, but some siblings have checks
        setCheckedKeys(prev => prev.filter(key => key !== 'sub1' && key !== currentKey));
        setHalfCheckedKeys(prev => [...prev.filter(key => key !== currentKey), 'sub1']);
      }
    } else if (partiallyChecked) {
      // Current node is partially checked
      setCheckedKeys(prev => prev.filter(key => key !== 'sub1' && key !== currentKey));
      setHalfCheckedKeys(prev => [...prev.filter(key => !['sub1', currentKey].includes(key.toString())), 'sub1', currentKey]);
    }
  };

  const handleSelectAll = (e: CheckboxChangeEvent) => {
    const newData = tableData.map(item => ({
      ...item,
      checked: e.target.checked,
      activities: item.activities.map(activity => ({
        ...activity,
        checked: e.target.checked,
      })),
    }));
    
    setTableData(newData);
    if (selectedMenuKey) {
      setMenuState(prev => ({
        ...prev,
        [selectedMenuKey]: {
          data: newData,
        },
      }));

      updateTreeState(newData, selectedMenuKey);
    }
  };

  const handleServiceCheck = (record: DataType, e: CheckboxChangeEvent) => {
    const newData = tableData.map(item => {
      if (item.key === record.key) {
        return {
          ...item,
          checked: e.target.checked,
          activities: item.activities.map(activity => ({
            ...activity,
            checked: e.target.checked,
          })),
        };
      }
      return item;
    });

    setTableData(newData);
    if (selectedMenuKey) {
      setMenuState(prev => ({
        ...prev,
        [selectedMenuKey]: {
          data: newData,
        },
      }));

      updateTreeState(newData, selectedMenuKey);
    }
  };

  const handleActivityCheck = (record: DataType, activityKey: string, e: CheckboxChangeEvent) => {
    const newData = tableData.map(item => {
      if (item.key === record.key) {
        const newActivities = item.activities.map(activity => 
          activity.key === activityKey ? { ...activity, checked: e.target.checked } : activity
        );
        const allActivitiesChecked = newActivities.every(activity => activity.checked);
        return {
          ...item,
          activities: newActivities,
          checked: allActivitiesChecked
        };
      }
      return item;
    });

    setTableData(newData);
    if (selectedMenuKey) {
      setMenuState(prev => ({
        ...prev,
        [selectedMenuKey]: {
          data: newData,
        },
      }));

      updateTreeState(newData, selectedMenuKey);
    }
  };

  const columns: ColumnsType<DataType> = [
    {
      title: (
        <div>
          <Checkbox
            checked={
              tableData.length > 0 && 
              tableData.every(item => 
                item.checked && item.activities.every(activity => activity.checked)
              )
            }
            indeterminate={
              tableData.length > 0 && 
              (tableData.some(item => item.checked || item.activities.some(activity => activity.checked))) &&
              !tableData.every(item => 
                item.checked && item.activities.every(activity => activity.checked)
              )
            }
            onChange={handleSelectAll}
          >
            服务
          </Checkbox>
        </div>
      ),
      dataIndex: 'service',
      width: 200,
      fixed: 'left' as const,
      render: (_: any, record: DataType) => (
        <Checkbox
          checked={record.checked && record.activities.every(activity => activity.checked)}
          indeterminate={
            (!record.checked && record.activities.some(activity => activity.checked)) ||
            (record.checked && !record.activities.every(activity => activity.checked))
          }
          onChange={(e) => handleServiceCheck(record, e)}
        >
          {record.service}
        </Checkbox>
      ),
    },
    {
      title: '活动',
      dataIndex: 'activities',
      render: (_: any, record: DataType) => (
        <Row gutter={[8, 8]} style={{width: "600px"}}>
          {record.activities.map(activity => (
            <Col key={activity.key} span={3}>
              <Checkbox
                checked={activity.checked}
                onChange={(e) => handleActivityCheck(record, activity.key, e)}
              >
                {activity.name}
              </Checkbox>
            </Col>
          ))}
        </Row>
      ),
    },
  ];

  const handleSave = () => {
    message.success('保存成功');
  };

  return (
    <div>
      <div style={{ display: 'flex' }}>
        <div style={{ width: '20%' }}>
          <div className="nc-bill-table-area">
            <Tree
              showLine
              checkable
              defaultExpandedKeys={['sub1']}
              onSelect={onSelect}
              onCheck={onCheck}
              checkedKeys={{
                checked: checkedKeys,
                halfChecked: halfCheckedKeys,
              }}
              checkStrictly={true}
              treeData={treeData}
              showIcon 
              style={{
                background: '#fff',
                borderRadius: '2px',
                height: 'calc(100vh - 280px)',
                overflowY: 'auto'
              }}
            />
          </div>
        </div>
        <div style={{ width: '80%', marginLeft: '10px' }}>
          <div className="nc-bill-table-area">
            <Table
              columns={columns}
              dataSource={tableData}
              rowKey="key"
              pagination={false}
              scroll={{ x: 'max-content', y: 'calc(100vh - 280px)' }}
              bordered={true}
            />
          </div>
          <div style={{ marginTop: '20px', textAlign: 'right' }}>
            <Button type="primary" danger onClick={handleSave}>
              保存
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PermissionManagement;